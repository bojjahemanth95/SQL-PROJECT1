# Library-Management-System-using-SQL
This is a small project on SQL contains all the required solutions for different queries on the data of Library.
I have uploaded some scenarios for the data retrieval from the tables with the solutions.
